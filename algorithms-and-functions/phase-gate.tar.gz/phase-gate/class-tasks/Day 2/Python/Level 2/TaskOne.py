number = int(input("Enter number: ")

if number % 2 == 0: print("Number is even")
else: print("Number is odd")
