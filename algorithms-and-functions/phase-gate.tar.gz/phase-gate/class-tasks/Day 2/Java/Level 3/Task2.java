public class Task2{
    public static void main(String[] args){
        for (int num = 1; num <= 100; num++){
            System.out.print(num);
        }
        System.out.println();
    }
}
